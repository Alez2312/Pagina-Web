<?php
$conexion = mysqli_connect("localhost", "root", "", "compañeros porSimilitud");
mysqli_set_charset($conexion, "utf8");
?>
