<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title>Login</title>
    <link rel="stylesheet" href="../styles/login.css">
</head>

<body>
    <div class="container">
        <h1 class="label">Compañeros por similitud</h1>
        <form class="login_form" action="inicio.php" method="post" name="form" onsubmit="return validated()">
            <div class="font">Usuario:</div>
            <input id="username" autocomplete="off" type="text" name="username">
            <div id="username_error">Por favor ingrese un usuario</div>
            <div class="font font2">Contraseña</div>
            <input id="password" type="password" name="password">
            <div id="password_error">Por favor ingrese una contraseña</div>
            <button type="submit">Ingresar</button>
        </form>
    </div>
    <script src="../js/login.js"></script>
</body>

</html>