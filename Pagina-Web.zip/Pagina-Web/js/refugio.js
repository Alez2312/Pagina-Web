let toggle = document.querySelector(".toggle");

function Animatedtoggle(){
    toggle.classList.toggle("active");
}